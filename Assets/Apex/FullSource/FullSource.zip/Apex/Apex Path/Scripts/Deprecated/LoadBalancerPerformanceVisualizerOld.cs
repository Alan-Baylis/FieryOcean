﻿/* Copyright © 2014 Apex Software. All rights reserved. */
#pragma warning disable 1591
namespace Apex.Debugging
{
    using UnityEngine;

    [AddComponentMenu("")]
    public class LoadBalancerPerformanceVisualizerOld : MonoBehaviour
    {
        private void Awake()
        {
            Debug.LogWarning("This scene contains deprecated components, please run Tools -> Apex -> Update Scene.");
        }
    }
}
