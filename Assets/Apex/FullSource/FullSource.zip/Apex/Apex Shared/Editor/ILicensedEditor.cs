﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex.Editor
{
    /// <summary>
    /// Simple marker interface for licensed editors to facilitate UI refresh in license changes.
    /// </summary>
    public interface ILicensedEditor
    {
    }
}
