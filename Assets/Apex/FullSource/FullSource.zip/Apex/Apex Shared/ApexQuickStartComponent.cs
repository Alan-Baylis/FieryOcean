﻿/* Copyright © 2014 Apex Software. All rights reserved. */
namespace Apex
{
    using UnityEngine;

    public abstract class ApexQuickStartComponent : MonoBehaviour
    {
        public abstract GameObject Apply(bool isPrefab);
    }
}
